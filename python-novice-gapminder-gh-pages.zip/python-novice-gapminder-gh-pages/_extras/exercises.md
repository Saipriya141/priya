---
title: "Further Exercises"
---
FIXME: exercises that don't fit into the regular schedule.
