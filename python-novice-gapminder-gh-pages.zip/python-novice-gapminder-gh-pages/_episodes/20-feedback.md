---
title: "Feedback"
teaching: 0
exercises: 15
questions:
- "How did the class go?"
objectives:
- "Gather feedback on the class"
keypoints:
- "We are constantly seeking to improve this course."
---

Gather feedback from participants.
