---
layout: break
title: "Morning Coffee"
teaching: 0
exercises: 0
break: 15
---
# Reflection exercise

Over coffee, reflect on and discuss the following:
* What are the different kinds of errors Python will report?
* Did the code always produce the results you expected? If not, why?
* Is there something we can do to prevent errors when we write code?
